![Banner](images/banner.jpg)
# Course Managment System

Required
* NetBeans IDE 12.0
* JDK 11 (LTS)
* MySQL 8
* MySQL Connector
* rs2xml
* FlatLaf
