package DBConnector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author ADITYA N SAH
 */
public class Const {
    public final static String db = "cms";
    public static String user = "root";
    public static String pass = "root";
    public static String url = "jdbc:mysql://localhost:3306/" + db + "?autoReconnect=true&useSSL=false";
}
